import numpy as np
import pandas as pd
from scipy import constants as cst
from scipy.optimize import root
from .globals import grids
from .xline import DominantXLine
from .fieldlines import DrapedFieldLines
import os
import matplotlib.pyplot as plt


from spok.models import planetary as smp
from spok import smath as sm
from spok.coordinates import coordinates as scc
from spok import utils as su


class MPMap:
    def __init__(self, data=None, **kwargs):
        """
        Keyword arguments:
        ------------------

        clock: float, (default:-90)
                IMF clock angle in degrees, 0 is due north

        cone: float, (default: 55)
                IMF cone angle in degrees, 0 is radial IMF

        tilt: float, (default: 0)
                Dipole tilt axis

        bimf: float, (default: 5)
                IMF amplitude in nT

        nws: float (default 5)
                solar wind density, in cm^-3

        mp_thick: float, (default 800)
                Magnetopause thickness in km
                only used for computing the current density

        data: dict, optional
                Pre-loaded grid arrays. When provided, disk loading is skipped.
                Expected keys: 'coordinates' (dict with Xmp, Ymp, Zmp, theta, phi),
                'bmsp', 'bmsh', 'nmsp', 'nmsh' (each a dict mapping angle-string to array).
                Used by the Pyodide webapp to inject fetched npz slices.
        """
        self._clock = kwargs.get("clock", -90)
        self._cone = kwargs.get("cone", 55)
        self._tilt = kwargs.get("tilt", 0)
        self._bimf = kwargs.get("bimf", 5)
        self._nsw = kwargs.get("nsw", 5)
        self._mp_thick = kwargs.get("mp_thick", 800)

        if data is None:
            self._load_grids()
        else:
            self._set_grids_from_data(data)

        self._build_map_grid()
        self.bmsp = self._grid_bmsp[str(self._tilt)]
        self.bmsh = self._processing_bmsh()
        self.nmsp = self._grid_nmsp[str(self._tilt)]
        self.nmsh = self._processing_nmsh()

    def _load_grids(self):
        from platformdirs import user_data_dir
        self._grid_path = os.path.join(user_data_dir(), "mpmaps")
        self._Xmp, self._Ymp, self._Zmp, self._theta, self._phi = pd.read_pickle(
            os.path.join(self._grid_path, grids[0])
        ).values()
        self._grid_bmsp = pd.read_pickle(os.path.join(self._grid_path, grids[1]))
        self._grid_bmsh = pd.read_pickle(os.path.join(self._grid_path, grids[2]))
        self._grid_nmsp = pd.read_pickle(os.path.join(self._grid_path, grids[3]))
        self._grid_nmsh = pd.read_pickle(os.path.join(self._grid_path, grids[4]))

    def _set_grids_from_data(self, data):
        c = data["coordinates"]
        self._Xmp = c["Xmp"]
        self._Ymp = c["Ymp"]
        self._Zmp = c["Zmp"]
        self._theta = c["theta"]
        self._phi = c["phi"]
        self._grid_bmsp = data["bmsp"]
        self._grid_bmsh = data["bmsh"]
        self._grid_nmsp = data["nmsp"]
        self._grid_nmsh = data["nmsh"]

    def __repr__(self):
        return f"""IMF clock angle    (°) : {self._clock}
IMF cone angle     (°) : {self._cone}
Dipole tilt angle  (°) : {self._tilt}
IMF amplitude (nT)     : {self._bimf}
Solar wind particle density : {self._nsw}
Magnetopause thickness : {self._mp_thick}
"""

    def _build_map_grid(self):
        """
        build the final map coordinates (2D)
        these are cartesian coords with uniform
        spacing in Y and Z.
        X is obtained for each Yi,Zi by interpolating
        the Xmp=(Ymp,Zmp) representing the cartesian
        coordinates from the uniform spherical coords
        of the magnetopause model
        """
        self._ny = 401
        self._nz = 401
        self._ymin = -22
        self._ymax = 22
        self._zmin = -22
        self._zmax = 22
        self.Y, self.Z = np.meshgrid(
            np.linspace(self._ymin, self._ymax, self._ny),
            np.linspace(self._zmin, self._zmax, self._nz),
            indexing="xy",
        )
        self.X = su.regular_grid_interpolation(
            self._Ymp, self._Zmp, self._Xmp, self.Y, self.Z
        )

    def _processing_bmsh(self):
        bxmsh, bymsh, bzmsh = self._grid_bmsh[str(abs(self._cone))]
        if self._cone < 0:
            bxmsh, bymsh, bzmsh = self._bmsh_for_negative_cone_angle(
                bxmsh, bymsh, bzmsh
            )
        bxmsh, bymsh, bzmsh = self._rotates_bmsh(bxmsh, bymsh, bzmsh)
        bxmsh, bymsh, bzmsh = [
            su.nan_gaussian_filter(b, (20, 20)) for b in [bxmsh, bymsh, bzmsh]
        ]
        bxmsh, bymsh, bzmsh = self._remove_normal_to_shue98(bxmsh, bymsh, bzmsh)
        bxmsh, bymsh, bzmsh = [b * self._bimf for b in [bxmsh, bymsh, bzmsh]]
        return bxmsh, bymsh, bzmsh

    def _bmsh_for_negative_cone_angle(self, bxmsh, bymsh, bzmsh):
        bxmsh, bzmsh = [
            su.regular_grid_interpolation(
                -self._Ymp, self._Zmp, [-b], self._Ymp, self._Zmp
            )
            for b in [bxmsh, bzmsh]
        ]
        return bxmsh, bymsh, bzmsh

    def _rotates_bmsh(self, bxmsh, bymsh, bzmsh):
        rotation_angle = (
            np.radians(self._clock) - np.pi / 2
        )  # pi/2 for standard orientation of
        new_xmp, new_ymp, new_zmp = scc.rotates_from_phi_angle(
            self._Xmp, self._Ymp, self._Zmp, rotation_angle
        )
        bx_new, by_new, bz_new = scc.rotates_from_phi_angle(
            bxmsh, bymsh, bzmsh, rotation_angle
        )
        bxmsh, bymsh, bzmsh = [
            su.regular_grid_interpolation(new_ymp, new_zmp, b, self.Y, self.Z)
            for b in [bx_new, by_new, bz_new]
        ]
        return bxmsh, bymsh, bzmsh

    def _remove_normal_to_shue98(self, bxmsh, bymsh, bzmsh):
        theta, phi = scc.cartesian_to_spherical(self.X, self.Y, self.Z)[1:]
        nx, ny, nz = smp.mp_shue1998_normal(theta, phi)
        bn = nx * bxmsh + ny * bymsh + nz * bzmsh
        return bxmsh - bn * nx, bymsh - bn * ny, bzmsh - bn * nz

    def _processing_nmsh(self):
        nmsh = self._grid_nmsh[str(abs(self._cone))]
        if self._cone < 0:
            nmsh = su.regular_grid_interpolation(
                -self._Ymp, self._Zmp, nmsh, self._Ymp, self._Zmp
            )
        nmsh = self._rotates_nmsh(nmsh)
        nmsh = su.nan_gaussian_filter(nmsh, (20, 20))
        nmsh = nmsh * self._nsw
        return nmsh

    def _rotates_nmsh(self, nmsh):
        rotation_angle = (
            np.radians(self._clock) - np.pi / 2
        )  # pi/2 for standard orientation of
        new_xmp, new_ymp, new_zmp = scc.rotates_from_phi_angle(
            self._Xmp, self._Ymp, self._Zmp, rotation_angle
        )
        return su.regular_grid_interpolation(new_ymp, new_zmp, nmsh, self.Y, self.Z)

    def set_parameters(self, **kwargs):
        if "tilt" in kwargs:
            self._tilt = kwargs["tilt"]
            self.bmsp = self._grid_bmsp[str(self._tilt)]
            self.nmsp = self._grid_nmsp[str(self._tilt)]
        if ("clock" in kwargs) or ("cone" in kwargs):
            if "clock" in kwargs:
                self._clock = kwargs["clock"]
            if "cone" in kwargs:
                self._cone = kwargs["cone"]
            self.bmsh = self._processing_bmsh()
            self.nmsh = self._processing_nmsh()
        if "bimf" in kwargs:
            self._bimf = kwargs["bimf"]
        if "nsw" in kwargs:
            self._nsw = kwargs["nsw"]
        if "mp_thick" in kwargs:
            self._mp_thick = kwargs["mp_thick"]

    def set_tilt(self, tilt):
        self._tilt = tilt
        self.bmsp = self._grid_bmsp[str(self._tilt)]
        self.nmsp = self._grid_nmsp[str(self._tilt)]

    def set_clock(self, clock):
        self._clock = clock
        self.bmsh = self._processing_bmsh()
        self.nmsh = self._processing_nmsh()

    def set_cone(self, cone):
        self._cone = cone
        self.bmsh = self._processing_bmsh()
        self.nmsh = self._processing_nmsh()

    def shear_angle(self):
        Bxmsp, Bymsp, Bzmsp = self.bmsp
        Bxmsh, Bymsh, Bzmsh = self.bmsh
        dp = Bxmsh * Bxmsp + Bymsh * Bymsp + Bzmsh * Bzmsp
        Bmsh = sm.norm(Bxmsh, Bymsh, Bzmsh)
        Bmsp = sm.norm(Bxmsp, Bymsp, Bzmsp)
        shear = np.degrees(np.arccos(dp / (Bmsh * Bmsp)))
        self._shear = shear
        return shear

    def current_density(self):
        bxmsp, bymsp, bzmsp = self.bmsp
        bxmsh, bymsh, bzmsh = self.bmsh
        bmsp_norm = sm.norm(bxmsp, bymsp, bzmsp)
        lx, ly, lz = bxmsp / bmsp_norm, bymsp / bmsp_norm, bzmsp / bmsp_norm
        Blmsh = bxmsh * lx + bymsh * ly + bzmsh * lz
        Blmsp = bxmsp * lx + bymsp * ly + bzmsp * lz
        th, ph = scc.cartesian_to_spherical(self.X, self.Y, self.Z)[1:]
        nx, ny, nz = smp.mp_shue1998_normal(th, ph)
        mx, my, mz = np.cross(np.asarray([nx, ny, nz]).T, np.asarray([lx, ly, lz]).T).T
        Bmmsh = bxmsh * mx + bymsh * my + bzmsh * mz
        Bmmsp = bxmsp * mx + bymsp * my + bzmsp * mz
        jl = -(Bmmsh - Bmmsp) * 1e-9 / (cst.mu_0 * self._mp_thick * 1e3)
        jm = (Blmsh - Blmsp) * 1e-9 / (cst.mu_0 * self._mp_thick * 1e3)
        jj = sm.norm(0, jl, jm) * 1e9
        jx = (jm * mx + jl * lx) * 1e9
        jy = (jm * my + jl * ly) * 1e9
        jz = (jm * mz + jl * lz) * 1e9
        return jj, jx, jy, jz

    def reconnection_rate(self, rec_angle="max_rate"):
        alpha = self.shear_angle()
        n1 = self.nmsp * 1e6 * cst.m_p
        n2 = self.nmsh * 1e6 * cst.m_p
        B1 = sm.norm(*self.bmsp) * 1e-9
        B2 = sm.norm(*self.bmsh) * 1e-9
        k = 2 * 0.1 * 1e3 / np.sqrt(cst.mu_0)

        if rec_angle == "max_rate":
            theta = self._find_rec_angle_max_rate()
        elif rec_angle == "bisection":
            theta = alpha / 2

        b1 = B1 * np.sin(np.radians(theta))
        b2 = B2 * np.sin(np.radians(alpha - theta))
        u = (b1 * b2) ** (3 / 2)
        v = np.sqrt((b2 * n1 + b1 * n2) * (b1 + b2))
        R = k * u / v
        return R

    def draped_field_lines(self, seed_spacing=2.5, min_sep=2.0, step=0.1):
        """Draped magnetosheath field lines on the magnetopause.

        Returns a list of dicts with keys ``x``/``y``/``z`` — one per line.
        See mpmaps.fieldlines.DrapedFieldLines.
        """
        return DrapedFieldLines(self).lines(
            seed_spacing=seed_spacing, min_sep=min_sep, step=step
        )

    def field_line_through(self, y0, z0, step=0.1):
        """Single draped msh field line through the seed point (y0, z0).

        Returns {"x","y","z","seed_index"} or None if off the dayside.
        See mpmaps.fieldlines.DrapedFieldLines.line_through.
        """
        return DrapedFieldLines(self).line_through(y0, z0, step=step)

    def dominant_xline(self, cusp=None, n_scan=21, step=0.1):
        """Dominant reconnection X-line for the current conditions.

        The X-line is the single best in-band traversal of the cusp band — the
        segment maximizing J = int R ds, scored independently (never summed
        across a curve's multiple crossings). Returns a dict with the ordered
        curve ``x``/``y``/``z`` on the MP (already clipped to the band), the
        reconnection rate ``R`` along it, its integrated rate ``J``, the winning
        seed ``seed = (y, z)`` and its family ``seed_family`` ("noon" or
        "equator"), and the cusp latitudes ``cusp_z_south`` / ``cusp_z_north``
        (detected from the ``|B_msp|`` null on the noon meridian; kept for
        reference). Pass ``cusp=(z_south, z_north)`` to override the detection.
        See mpmaps.xline.DominantXLine.
        """
        return DominantXLine(self).xline(cusp=cusp, n_scan=n_scan, step=step)

    def plot(self, **kwargs):
        """
        Keyword arguments
        -----------------

        value : string ("shear_angle":default, "reconnection_rate", "current_density")
                the quantity that is plotted

        xlim : tuple, lower bound of the plot area
        ylim : tuple, upper bound of the plot area
        filename : string, file name to save the figure on disk

        other keywork arguments: see MPMap

        example : mp.plot(value="shear_angle", tilt=14, xlim=(-18,18), ylim=(-18,18))
        """

        if "ax" in kwargs:
            ax = kwargs["ax"]
            fig = ax.get_figure()
        else:
            fig, ax = plt.subplots()

        msh = smp.Magnetosheath()
        phi = np.arange(0, np.pi * 2 + 0.1, 0.1)
        theta = np.pi / 2
        _, y, z = msh.magnetopause(theta, phi)
        ax.plot(y, z, ls="--", color="k")

        xmin, xmax = kwargs.get("xlim", (self.Y.min(), self.Y.max()))
        ymin, ymax = kwargs.get("ylim", (self.Z.min(), self.Z.max()))

        ax.set_xlim((xmin, xmax))
        ax.set_ylim((ymin, ymax))
        ax.set_xlabel(r"$Y/R_e$")
        ax.set_ylabel(r"$Z/R_e$")

        self.set_parameters(**kwargs)
        val = kwargs.get("value", "shear_angle")
        sa = getattr(self, val)()

        ax.pcolormesh(self.Y, self.Z, sa, cmap="jet")
        ax.axvline(0, ls="--", color="k")
        ax.axhline(0, ls="--", color="k")
        ax.set_aspect("equal")

        if "filename" in kwargs:
            fig.savefig(kwargs["filename"])

        return fig, ax

    def plot3d(self, **kwargs):
        """
        Render a 3D PyVista scene of a quantity on the dayside magnetopause.

        Requires pyvista: pip install pyvista

        Keyword arguments
        -----------------
        quantity : str
            'shear_angle' (default), 'reconnection_rate', or 'current_density'
        camera : str or list
            'oblique' (default), 'trattner', or explicit [[pos],[focal],[up]]
        dark_mode : bool (default True)
        interactive : bool (default False)
            Open an interactive window; prints final camera position on close.
        filename : str or None
            Path to save a PNG screenshot.
        x_plane : float (default 0.0)
            X position of the upstream projection plane in Re.
        y_plane : float (default -50.0)
            Y offset of the projection plane from the 3D surface in Re.
        x_min : float (default 1.0)
            Minimum X cutoff for the magnetopause surface in Re.
        vmax : float or None
            Color scale upper bound; auto-computed from data if None.

        Returns
        -------
        pv.Plotter
        """
        from .viz3d import render_scene
        return render_scene(self, **kwargs)

    def _find_rec_angle_max_rate(self):
        def _dRR_dtheta_local(theta, params):
            n1 = params[:, 0] * 1e6 * cst.m_p
            n2 = params[:, 1] * 1e6 * cst.m_p
            B1 = sm.norm(params[:, 2], params[:, 3], params[:, 4]) * 1e-9
            B2 = sm.norm(params[:, 5], params[:, 6], params[:, 7]) * 1e-9
            alpha = parameters[:, -1]
            k = 2 * 0.1 * 1e3 / np.sqrt(cst.mu_0)
            b1 = B1 * np.sin(np.radians(theta))
            b2 = B2 * np.sin(np.radians(alpha - theta))
            b1p = B1 * np.cos(np.radians(theta))
            b2p = -B2 * np.cos(np.radians(alpha - theta))
            b1b2p = b1p * b2 + b2p * b1
            u = (b1 * b2) ** (3 / 2)
            v = np.sqrt((b2 * n1 + b1 * n2) * (b1 + b2))
            up = 3 / 2 * b1b2p * np.sqrt(b1 * b2)
            vp = (2 * b1 * b1p * n2 + 2 * b2 * b2p * n1 + ((b1b2p) * (n1 + n2))) / (
                2 * v
            )
            Rp = k * (up * v - vp * u) / (v**2)
            return Rp

        alpha = self.shear_angle()
        parameters, old_shape = su.reshape_to_2Darrays(
            [
                self.nmsp,
                self.nmsh,
                self.bmsp[0],
                self.bmsp[1],
                self.bmsp[2],
                self.bmsh[0],
                self.bmsh[1],
                self.bmsh[2],
                alpha,
            ]
        )
        rt = root(
            _dRR_dtheta_local,
            x0=parameters[:, -1] / 2,
            args=parameters,
            method="krylov",
        )
        theta = su.reshape_to_original_shape(rt.x, (1, old_shape[1], old_shape[2]))[0]
        if np.sum(rt.success == 0) != 0:
            print("Convergence problem")
        return theta
